const axios = require("axios");

module.exports.getToken = async (event) => {
  try {
    // event.body viene como string, lo parseamos
    const body = JSON.parse(event.body);

    // Construimos el payload igual que en Angular
    const params = {
      code: body.code,
      grant_type: "authorization_code",
      redirect_uri: process.env.REDIRECT_URI,
      client_id: process.env.CLIENT_ID,
      client_secret: process.env.CLIENT_SECRET,
    };

    // Llamamos al API de Mercado Libre
    const response = await axios.post(process.env.TARGET_BASE_URL, params, {
      headers: {
        "Content-Type": "application/json",
      },
    });
    console.log({response});

    // Devolvemos la respuesta del API
    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*", // habilita CORS
        "Access-Control-Allow-Credentials": true,
      },
      body: JSON.stringify(response.data),
    };
  } catch (error) {
    console.error(
      "Error:",
      error.response ? error.response.data : error.message
    );

    return {
      statusCode: error.response?.status || 500,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Credentials": true,
      },
      body: JSON.stringify({
        message: "Error obteniendo el token",
        error: error.response?.data || error.message,
      }),
    };
  }
};
